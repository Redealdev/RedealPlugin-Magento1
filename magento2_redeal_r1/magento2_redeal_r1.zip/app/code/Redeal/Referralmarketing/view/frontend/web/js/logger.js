define(function() {
    "use strict";
 
    return {
        log : function(param){
            console.log(param);
        }
    };
});