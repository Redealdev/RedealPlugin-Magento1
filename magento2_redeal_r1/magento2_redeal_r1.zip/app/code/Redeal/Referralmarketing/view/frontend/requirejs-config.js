var config = {
    map: {
        '*': {
            redeal: 'Redeal_Referralmarketing/js/redeal',
            logger: 'Redeal_Referralmarketing/js/logger'
        }
    }
};

