define('jquery', function($) {

    //Your code here
     alert('Here');

    }(jQuery)
);

